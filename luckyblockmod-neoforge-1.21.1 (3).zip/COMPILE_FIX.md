# NeoForge 1.21.1 compile fixes

This source revision addresses the compiler errors reported by the first GitHub Actions run and the additional error excerpt supplied in chat.

- Fixed ambiguous `Level.getEntities` usage with `getEntitiesOfClass(Entity.class, ...)`.
- Updated item max-stack-size access to use an `ItemStack`.
- Updated mob spawn initialization to the 1.21.1 four-argument `finalizeSpawn` signature.
- Updated `LargeFireball` construction to accept a direction `Vec3` and explosion power.
- Added `Fx.sound` overloads for both `SoundEvent` and `Holder<SoundEvent>` constants.
- Changed `setSecondsOnFire` calls to `setRemainingFireTicks`.
- Replaced removed `LivingAttackEvent` with `LivingIncomingDamageEvent`.
- Removed deleted `DistExecutor` references and used `IPayloadContext.enqueueWork` (plus a client-side guard for GUI opening).

Validation is static only. A complete Forge/NeoForge Gradle build must run in GitHub Actions to confirm the JAR compiles.
