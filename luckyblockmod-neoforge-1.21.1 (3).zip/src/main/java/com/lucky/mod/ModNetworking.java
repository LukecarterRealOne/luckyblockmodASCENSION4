package com.lucky.mod;

import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/** NeoForge 1.21.1 custom-payload networking replacing Forge SimpleChannel. */
public final class ModNetworking {
    private ModNetworking() {}

    public static void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(LuckyBlockMod.PROTOCOL);
        registrar.playToClient(FxPacket.TYPE, FxPacket.STREAM_CODEC, FxPacket::handleClient);
        registrar.playToServer(SelectPacket.TYPE, SelectPacket.STREAM_CODEC, SelectPacket::handleServer);
        registrar.playToClient(OpenItemWishPacket.TYPE, OpenItemWishPacket.STREAM_CODEC,
                OpenItemWishPacket::handleClient);
        registrar.playToServer(WishItemPacket.TYPE, WishItemPacket.STREAM_CODEC, WishItemPacket::handleServer);
    }

    public static void sendToPlayer(ServerPlayer player, CustomPacketPayload payload) {
        PacketDistributor.sendToPlayer(player, payload);
    }

    public static void sendToServer(CustomPacketPayload payload) {
        PacketDistributor.sendToServer(payload);
    }
}
