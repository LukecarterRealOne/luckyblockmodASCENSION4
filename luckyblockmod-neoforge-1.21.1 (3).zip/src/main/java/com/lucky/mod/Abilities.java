package com.lucky.mod;

/** Names and short descriptions shown by the compact, paged ability selector. */
public final class Abilities {
    private Abilities() {}

    public static final String[] NAMES = {
            "Omega Beam", "Lightning Storm", "Meteor Shower", "Healing Nova", "Sky Launch", "Item Rain",
            "Gravity Warp", "Ally Summon", "Orbital Strike", "Aegis Shield", "Guardian Legion",
            "Black Hole", "Frost Nova", "Hurricane", "Dragon Breath", "Projectile Storm", "Blink Strike", "Overdrive",
            "Yellow Flight", "Time Stop", "Time Surge", "Void Rift", "Giant Tesseract", "Ally Command",
            "Lucky Ascension", "Reality Break", "Chrono Burst", "Dimension Shift", "Cosmic Nova", "Item Wish",
            "Time Replay", "Spatial Deflection", "Absolute Aegis", "Thunder God"
    };

    public static final String[] DESCRIPTIONS = {
            "A precise, long-range beam that burns a path through targets.",
            "Calls repeated lightning strikes around you.",
            "Drops a volley of fireballs on the point you aim at.",
            "Restores nearby living entities and clears harmful effects.",
            "Launches you upward with a controlled slow fall.",
            "Drops a spread of random vanilla and modded items.",
            "Lifts enemies in a gravity well, then slams them down.",
            "Summons a squad of random registered modded allies.",
            "Charges and fires a towering orbital beam at your target.",
            "A blue force field deflects projectiles and repels mobs, with resistance and absorption.",
            "Summons a durable squad of six guardian golems.",
            "Creates a sustained singularity that drags enemies inward.",
            "Freezes and instantly defeats nearby enemies.",
            "Creates a wide, rotating hurricane that lifts and swirls enemies.",
            "Projects a forward cone of scorching dragon fire.",
            "Rains registered vanilla and modded projectiles over your target.",
            "Teleports you to your aim point and strikes nearby enemies.",
            "A 15-second offense rush: strength, speed, haste, and jumping—no defense buffs.",
            "Enables true flight for a limited time, with a gold particle trail.",
            "Locks hostile mobs in place while you move freely.",
            "Accelerates movement and mining without the heavy combat buffs.",
            "Opens a focused void tear that weakens and drains nearby enemies.",
            "A rotating 4D hypercube: two perspective cubes, eight bridges, and a crushing collapse.",
            "Commands your own summoned allies to attack the entity you aim at.",
            "Restores you and grants a long-lasting suite of powerful buffs.",
            "Shuffles enemies between each other’s positions and briefly disorients them.",
            "Marks a targeted group with slow-motion, then lands a delayed time-debt hit.",
            "Teleports you to another loaded dimension, including modded ones.",
            "A purple shockwave blasts enemies away from you in expanding pulses.",
            "Opens a searchable catalogue to choose any registered vanilla or modded item.",
            "Rewinds your position and health to a recent snapshot, if available.",
            "Raises a colossal tesseract over the target zone, lifts hostiles and projectiles, then banishes them.",
            "True damage immunity for 60 seconds, with strong regeneration and absorption.",
            "Chains focused lightning strikes from one target to nearby enemies."
    };

    public static final int COUNT = NAMES.length;
    public static final int PER_PAGE = 10;
}
